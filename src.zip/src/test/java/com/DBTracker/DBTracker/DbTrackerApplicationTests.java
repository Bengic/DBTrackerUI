package com.DBTracker.DBTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
